﻿'Nic Lake
'6 Oct 2010
'Bus. App. Dev. II
'Practice utilizing functions

Public Class MainForm

    Private Sub CalcButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CalcButton.Click
        'declare variables
        Dim SalaryDecimal As Decimal
        Dim YearsInteger As Integer

        Try
            SalaryDecimal = Decimal.Parse(SalaryTextBox.Text)
            Try
                YearsInteger = Integer.Parse(YearsTextBox.Text)

                ResultLabel.Text = CheckQualifications(SalaryDecimal, YearsInteger)

            Catch YearsException As FormatException
                MessageBox.Show("Please enter a valid salary.", "Salary entry error")
                SalaryTextBox.SelectAll()
            End Try
        Catch SalaryException As FormatException
            MessageBox.Show("Please enter a valid number of years.", "Years entry error")
            YearsTextBox.SelectAll()
        End Try
    End Sub

    Function CheckQualifications(ByVal Salary As Decimal, ByVal Years As Integer)
        Dim Results As String

        If Salary > 50000 Then
            If Years > 2 Then
                Results = "You qualify!"
            Else
                Results = "You do not qualify."
            End If
        Else
            If Years > 5 Then
                Results = "You qualify!"
            Else
                Results = "You do not qualify."
            End If
        End If

        Return Results
    End Function

    Private Sub ExitButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitButton.Click
        Me.Close()
    End Sub

    Private Sub ClearButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearButton.Click
        SalaryTextBox.Text = ""
        YearsTextBox.Text = ""
        SalaryTextBox.Focus()
    End Sub
End Class

