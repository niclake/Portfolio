﻿'Project:     Price Calculator 
'Programmer:  
'Date:        September 2010
'Purpose:     Demonstrate one-way decision logic using string value comparisons

Option Strict On

Public Class MainForm

    

    Private Sub ClearButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearButton.Click
        'clear textboxes

        PriceTextBox.Clear()
        NewPriceTextBox.Clear()
        MessageLabel.Text = ""

        'clear and set focus in Product textbox
        With ProductTextBox
            .Clear()
            .Focus()
        End With

    End Sub

    Private Sub QuitButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles QuitButton.Click
        'close application
        Me.Close()

    End Sub

   
End Class
