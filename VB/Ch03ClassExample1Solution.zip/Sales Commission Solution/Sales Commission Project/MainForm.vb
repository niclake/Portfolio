﻿'Project:    Sales Commission Calculator  
'Programmer:
'Date:       September 2010
'purpose:    Demonstrate two-way decision logic using numeric value comparisons

Option Strict On



Public Class MainForm

   

    Private Sub ClearButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ClearButton.Click
        'Clear textboxes
        SalesGoalTextBox.Clear()
        CommissionTextBox.Clear()

        With SalesTextBox
            .Clear()
            .Focus()
        End With
    End Sub

    Private Sub ExitButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ExitButton.Click
        Me.Close()

    End Sub

    
End Class
